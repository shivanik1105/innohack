import React, { useState } from 'react';
import { useWorker } from '../contexts/WorkerContext';
import BlueCollarLogin from '../components/BlueCollarLogin';
import BlueCollarProfile from '../components/BlueCollarProfile';
import BlueCollarJobs from '../components/BlueCollarJobs';

const BlueCollarFlow: React.FC = () => {
  const { worker, isAuthenticated } = useWorker();
  const [step, setStep] = useState(0);

  if (!isAuthenticated) {
    return <BlueCollarLogin onLogin={() => setStep(1)} />;
  }

  if (!worker?.name || !worker?.skills.length) {
    return <BlueCollarProfile onComplete={() => setStep(2)} />;
  }

  return <BlueCollarJobs />;
};

export default BlueCollarFlow;