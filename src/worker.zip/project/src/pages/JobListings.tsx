import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const JobListings: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center mb-8">
          <button 
            onClick={() => navigate('/')}
            className="mr-4 p-2 hover:bg-gray-100 rounded-lg"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-800">Job Listings</h1>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <p className="text-gray-600">Job listings will be displayed here based on your worker type and profile.</p>
        </div>
      </div>
    </div>
  );
};

export default JobListings;