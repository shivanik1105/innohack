import React, { useState } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import DailyWageLogin from '../components/DailyWageLogin';
import DailyWageProfile from '../components/DailyWageProfile';
import DailyWageJobs from '../components/DailyWageJobs';
import { useWorker } from '../contexts/WorkerContext';

const DailyWageFlow: React.FC = () => {
  const { worker, isAuthenticated } = useWorker();
  const [step, setStep] = useState(0);
  const navigate = useNavigate();

  if (!isAuthenticated) {
    return <DailyWageLogin onLogin={() => setStep(1)} />;
  }

  if (!worker?.name || !worker?.workType.length) {
    return <DailyWageProfile onComplete={() => setStep(2)} />;
  }

  return <DailyWageJobs />;
};

export default DailyWageFlow;