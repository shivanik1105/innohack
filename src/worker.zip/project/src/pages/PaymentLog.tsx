import React from 'react';
import { ArrowLeft, IndianRupee, Clock, Check, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const PaymentLog: React.FC = () => {
  const navigate = useNavigate();

  // Mock payment data
  const payments = [
    {
      id: '1',
      jobTitle: 'Construction Helper',
      contractor: 'ABC Construction',
      amount: 600,
      date: '2024-01-15',
      status: 'paid'
    },
    {
      id: '2',
      jobTitle: 'Loading Work',
      contractor: 'XYZ Logistics',
      amount: 550,
      date: '2024-01-14',
      status: 'pending'
    },
    {
      id: '3',
      jobTitle: 'Office Cleaning',
      contractor: 'Clean Corp',
      amount: 450,
      date: '2024-01-13',
      status: 'paid'
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'paid':
        return <Check className="w-5 h-5 text-green-600" />;
      case 'pending':
        return <Clock className="w-5 h-5 text-yellow-600" />;
      case 'overdue':
        return <AlertCircle className="w-5 h-5 text-red-600" />;
      default:
        return <Clock className="w-5 h-5 text-gray-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'overdue':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const totalPaid = payments.filter(p => p.status === 'paid').reduce((sum, p) => sum + p.amount, 0);
  const totalPending = payments.filter(p => p.status === 'pending').reduce((sum, p) => sum + p.amount, 0);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center mb-8">
          <button 
            onClick={() => navigate('/')}
            className="mr-4 p-2 hover:bg-gray-100 rounded-lg"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-gray-800">Payment Log</h1>
        </div>

        {/* Summary Cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Paid</p>
                <div className="flex items-center text-2xl font-bold text-green-600">
                  <IndianRupee className="w-6 h-6" />
                  <span>{totalPaid}</span>
                </div>
              </div>
              <div className="bg-green-100 p-3 rounded-full">
                <Check className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pending</p>
                <div className="flex items-center text-2xl font-bold text-yellow-600">
                  <IndianRupee className="w-6 h-6" />
                  <span>{totalPending}</span>
                </div>
              </div>
              <div className="bg-yellow-100 p-3 rounded-full">
                <Clock className="w-6 h-6 text-yellow-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Payment History */}
        <div className="bg-white rounded-lg shadow-sm">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-800">Payment History</h2>
          </div>
          <div className="divide-y divide-gray-200">
            {payments.map((payment) => (
              <div key={payment.id} className="p-6 hover:bg-gray-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-800">{payment.jobTitle}</h3>
                    <p className="text-sm text-gray-600">{payment.contractor}</p>
                    <p className="text-sm text-gray-500">{payment.date}</p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center text-lg font-bold text-gray-800 mb-2">
                      <IndianRupee className="w-5 h-5" />
                      <span>{payment.amount}</span>
                    </div>
                    <div className="flex items-center">
                      <div className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(payment.status)}`}>
                        {payment.status.toUpperCase()}
                      </div>
                      <div className="ml-2">
                        {getStatusIcon(payment.status)}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {payments.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-400 text-6xl mb-4">💰</div>
            <h3 className="text-lg font-medium text-gray-800 mb-2">
              No payment history yet
            </h3>
            <p className="text-gray-600">
              Complete your first job to see payments here
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PaymentLog;