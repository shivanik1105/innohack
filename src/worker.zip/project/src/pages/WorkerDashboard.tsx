import React from 'react';
import { ArrowLeft, User, Star, Briefcase, Award, TrendingUp, Shield, Zap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useWorker } from '../contexts/WorkerContext';
import SkillGrowthChart from '../components/SkillGrowthChart';
import JobStatusChart from '../components/JobStatusChart';
import AIJobSuggestions from '../components/AIJobSuggestions';
import ChatBot from '../components/ChatBot';

const WorkerDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { worker } = useWorker();

  // Mock data for enhanced worker
  const enhancedWorker = {
    ...worker,
    skillNFTs: 15,
    skillGrowthData: [
      { month: 'Jan', skills: 2 },
      { month: 'Feb', skills: 4 },
      { month: 'Mar', skills: 6 },
      { month: 'Apr', skills: 8 },
      { month: 'May', skills: 12 },
      { month: 'Jun', skills: 15 }
    ],
    recentActivity: [
      { type: 'NFT Earned', description: 'JavaScript Development Certificate', time: '2 hours ago' },
      { type: 'Job Completed', description: 'Electrical Installation at DLF Phase 3', time: '1 day ago' },
      { type: 'Rating Received', description: '5-star rating from TechHome Solutions', time: '2 days ago' }
    ],
    jobStatusData: { completed: 45, pending: 3, inProgress: 5 }
  };

  if (!worker) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-600">No worker profile found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center mb-8">
          <button 
            onClick={() => navigate('/')}
            className="mr-4 p-2 hover:bg-gray-100 rounded-lg"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Welcome back, Worker!</h1>
            <p className="text-gray-600">Your skill verification journey continues</p>
          </div>
          <div className="ml-auto flex items-center bg-blue-100 text-blue-800 px-3 py-1 rounded-full">
            <Shield className="w-4 h-4 mr-1" />
            <span className="text-sm font-medium">Verified</span>
          </div>
        </div>
        
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Skill NFTs Earned</p>
                <p className="text-2xl font-bold text-purple-600">{enhancedWorker.skillNFTs}</p>
              </div>
              <div className="bg-purple-100 p-3 rounded-full">
                <Award className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Jobs Completed</p>
                <p className="text-2xl font-bold text-green-600">{enhancedWorker.jobStatusData?.completed}</p>
              </div>
              <div className="bg-green-100 p-3 rounded-full">
                <Briefcase className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Average Rating</p>
                <p className="text-2xl font-bold text-yellow-600">{worker.rating}</p>
              </div>
              <div className="bg-yellow-100 p-3 rounded-full">
                <Star className="w-6 h-6 text-yellow-600" />
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Certifications</p>
                <p className="text-2xl font-bold text-blue-600">{worker.certifications.length}</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-full">
                <Shield className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <SkillGrowthChart data={enhancedWorker.skillGrowthData || []} />
          <JobStatusChart data={enhancedWorker.jobStatusData || { completed: 0, pending: 0, inProgress: 0 }} />
        </div>

        {/* AI Job Suggestions */}
        <div className="mb-8">
          <AIJobSuggestions />
        </div>

        {/* Profile Section */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 mb-8">
          <h2 className="text-xl font-bold text-gray-800 mb-6">Profile Information</h2>
          <div className="flex items-center mb-6">
            {worker.photo ? (
              <img 
                src={worker.photo} 
                alt={worker.name}
                className="w-20 h-20 rounded-full object-cover mr-6"
              />
            ) : (
              <div className="w-20 h-20 rounded-full bg-gray-200 flex items-center justify-center mr-6">
                <User className="w-10 h-10 text-gray-400" />
              </div>
            )}
            <div>
              <div className="flex items-center">
                <h2 className="text-2xl font-bold text-gray-800 mr-3">{worker.name}</h2>
                {worker.isVerified && (
                  <div className="flex items-center bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                    <Award className="w-4 h-4 mr-1" />
                    <span>Verified</span>
                  </div>
                )}
              </div>
              <p className="text-gray-600">{worker.phone}</p>
              <div className="flex items-center mt-2">
                <Star className="w-5 h-5 text-yellow-400 mr-1" />
                <span className="font-medium">{worker.rating}</span>
                <span className="text-gray-500 ml-2">({worker.jobsCompleted} jobs completed)</span>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-3">Skills</h3>
              <div className="space-y-2">
                {worker.skills.map((skill, index) => (
                  <div key={index} className="bg-gray-50 px-3 py-2 rounded-lg text-sm">
                    {skill}
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-3">Work Types</h3>
              <div className="space-y-2">
                {worker.workType.map((type, index) => (
                  <div key={index} className="bg-gray-50 px-3 py-2 rounded-lg text-sm">
                    {type}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="flex items-center justify-between">
              <span className="text-gray-700">Current Status</span>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                worker.isAvailable 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-red-100 text-red-800'
              }`}>
                {worker.isAvailable ? 'Available' : 'Not Available'}
              </span>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Activity</h3>
          <div className="space-y-4">
            {enhancedWorker.recentActivity?.map((activity, index) => (
              <div key={index} className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg">
                <div className="bg-blue-100 p-2 rounded-full">
                  {activity.type === 'NFT Earned' && <Award className="w-4 h-4 text-blue-600" />}
                  {activity.type === 'Job Completed' && <Briefcase className="w-4 h-4 text-green-600" />}
                  {activity.type === 'Rating Received' && <Star className="w-4 h-4 text-yellow-600" />}
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-800">{activity.type}</p>
                  <p className="text-sm text-gray-600">{activity.description}</p>
                  <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* ChatBot */}
      <ChatBot />
    </div>
  );
};

export default WorkerDashboard;