import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, Briefcase, Phone, Star } from 'lucide-react';

const LandingPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col justify-center items-center p-6">
      <div className="max-w-4xl w-full text-center mb-12">
        <h1 className="text-5xl font-bold text-gray-800 mb-4">
          रोजगार मित्र
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          Connect with daily wage opportunities near you
        </p>
        
        <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto">
          {/* Daily Wage Worker Card */}
          <div 
            onClick={() => navigate('/daily-wage')}
            className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer border-2 border-transparent hover:border-blue-200"
          >
            <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <Users className="w-8 h-8 text-blue-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-4">
              Daily Wage Worker
            </h2>
            <p className="text-gray-600 mb-6">
              Quick access to daily jobs. Simple phone login, no complicated forms.
            </p>
            <div className="flex items-center justify-center space-x-4 text-sm text-gray-500">
              <div className="flex items-center">
                <Phone className="w-4 h-4 mr-1" />
                <span>Phone Login</span>
              </div>
              <div className="flex items-center">
                <Briefcase className="w-4 h-4 mr-1" />
                <span>Quick Jobs</span>
              </div>
            </div>
          </div>

          {/* Blue-Collar Worker Card */}
          <div 
            onClick={() => navigate('/blue-collar')}
            className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer border-2 border-transparent hover:border-indigo-200"
          >
            <div className="bg-indigo-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <Star className="w-8 h-8 text-indigo-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-4">
              Skilled Worker
            </h2>
            <p className="text-gray-600 mb-6">
              Build your professional profile with certifications and ratings.
            </p>
            <div className="flex items-center justify-center space-x-4 text-sm text-gray-500">
              <div className="flex items-center">
                <Star className="w-4 h-4 mr-1" />
                <span>Verified Skills</span>
              </div>
              <div className="flex items-center">
                <Briefcase className="w-4 h-4 mr-1" />
                <span>Higher Pay</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <p className="text-gray-500 text-sm">
            Simple • Secure • No hidden fees
          </p>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;