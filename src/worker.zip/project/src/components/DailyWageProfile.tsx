import React, { useState } from 'react';
import { User, MapPin, Briefcase, Check, Mic } from 'lucide-react';
import { useWorker } from '../contexts/WorkerContext';
import VoiceInput from './VoiceInput';

interface DailyWageProfileProps {
  onComplete: () => void;
}

const DailyWageProfile: React.FC<DailyWageProfileProps> = ({ onComplete }) => {
  const { worker, setWorker } = useWorker();
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [pinCode, setPinCode] = useState('');
  const [selectedWork, setSelectedWork] = useState<string[]>([]);
  const [isAvailable, setIsAvailable] = useState(true);
  const [useVoice, setUseVoice] = useState(false);

  const workTypes = [
    { id: 'helper', label: 'Helper', icon: '👷' },
    { id: 'loader', label: 'Loader', icon: '📦' },
    { id: 'cleaner', label: 'Cleaner', icon: '🧹' },
    { id: 'laborer', label: 'Laborer', icon: '🔨' },
  ];

  const handleWorkTypeToggle = (workType: string) => {
    setSelectedWork(prev => 
      prev.includes(workType) 
        ? prev.filter(w => w !== workType)
        : [...prev, workType]
    );
  };

  const handleSave = () => {
    if (worker && name && age && pinCode && selectedWork.length > 0) {
      setWorker({
        ...worker,
        name,
        age: parseInt(age),
        pinCode,
        workType: selectedWork,
        isAvailable
      });
      onComplete();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8">
        {/* Voice Toggle */}
        <div className="flex justify-end mb-4">
          <button
            onClick={() => setUseVoice(!useVoice)}
            className={`flex items-center px-3 py-1 rounded-full text-sm transition-colors ${
              useVoice ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-600'
            }`}
          >
            <Mic className="w-4 h-4 mr-1" />
            Voice Mode
          </button>
        </div>

        <div className="text-center mb-8">
          <div className="bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
            <User className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">
            Complete Your Profile
          </h2>
          <p className="text-gray-600">
            Quick setup to find the right jobs for you
          </p>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Full Name
            </label>
            {useVoice ? (
              <div className="border border-gray-300 rounded-lg p-4">
                <VoiceInput
                  onResult={(text) => setName(text)}
                  placeholder="Say your full name"
                />
                {name && (
                  <p className="mt-2 text-sm text-green-600">✓ Name: {name}</p>
                )}
              </div>
            ) : (
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter your full name"
              />
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Age
              </label>
              <input
                type="number"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Age"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Pin Code
              </label>
              <input
                type="text"
                value={pinCode}
                onChange={(e) => setPinCode(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Pin Code"
                maxLength={6}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Type of Work (Select 1-2)
            </label>
            <div className="grid grid-cols-2 gap-3">
              {workTypes.map((work) => (
                <div
                  key={work.id}
                  onClick={() => handleWorkTypeToggle(work.id)}
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                    selectedWork.includes(work.id)
                      ? 'border-green-500 bg-green-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="text-2xl mb-2">{work.icon}</div>
                  <div className="font-medium text-gray-800">{work.label}</div>
                  {selectedWork.includes(work.id) && (
                    <Check className="w-5 h-5 text-green-500 mt-1" />
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium text-gray-800">Available Today?</h3>
                <p className="text-sm text-gray-600">Let employers know you're ready to work</p>
              </div>
              <div 
                onClick={() => setIsAvailable(!isAvailable)}
                className={`w-14 h-8 rounded-full cursor-pointer transition-colors relative ${
                  isAvailable ? 'bg-green-500' : 'bg-gray-300'
                }`}
              >
                <div 
                  className={`w-6 h-6 bg-white rounded-full absolute top-1 transition-transform ${
                    isAvailable ? 'translate-x-7' : 'translate-x-1'
                  }`}
                />
              </div>
            </div>
          </div>

          <button
            onClick={handleSave}
            disabled={!name || !age || !pinCode || selectedWork.length === 0}
            className="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
          >
            Save Profile & Continue
          </button>
        </div>
      </div>
    </div>
  );
};

export default DailyWageProfile;