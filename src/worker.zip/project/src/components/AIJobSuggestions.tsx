import React, { useState, useEffect } from 'react';
import { Brain, MapPin, IndianRupee, Clock, Star, Zap } from 'lucide-react';
import { useWorker } from '../contexts/WorkerContext';

interface SuggestedJob {
  id: string;
  title: string;
  contractor: string;
  location: string;
  payPerDay: number;
  matchScore: number;
  aiReason: string;
  urgency: 'high' | 'medium' | 'low';
  estimatedDuration: string;
}

const AIJobSuggestions: React.FC = () => {
  const { worker } = useWorker();
  const [suggestions, setSuggestions] = useState<SuggestedJob[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate AI job matching
    setTimeout(() => {
      const mockSuggestions: SuggestedJob[] = [
        {
          id: '1',
          title: 'Premium Electrical Installation',
          contractor: 'TechHome Solutions',
          location: 'DLF Phase 4, Gurgaon',
          payPerDay: 2500,
          matchScore: 95,
          aiReason: 'Perfect match for your electrical skills and 4.8★ rating',
          urgency: 'high',
          estimatedDuration: '3-5 days'
        },
        {
          id: '2',
          title: 'Smart Home Plumbing Setup',
          contractor: 'Modern Living Co.',
          location: 'Cyber City, Gurgaon',
          payPerDay: 2200,
          matchScore: 88,
          aiReason: 'Matches your plumbing expertise and location preference',
          urgency: 'medium',
          estimatedDuration: '2-3 days'
        },
        {
          id: '3',
          title: 'Commercial Maintenance',
          contractor: 'BuildPro Services',
          location: 'Golf Course Road, Gurgaon',
          payPerDay: 1800,
          matchScore: 82,
          aiReason: 'Good fit based on your maintenance experience',
          urgency: 'low',
          estimatedDuration: '1 week'
        }
      ];
      setSuggestions(mockSuggestions);
      setLoading(false);
    }, 2000);
  }, [worker]);

  const getMatchColor = (score: number) => {
    if (score >= 90) return 'text-green-600 bg-green-100';
    if (score >= 80) return 'text-yellow-600 bg-yellow-100';
    return 'text-orange-600 bg-orange-100';
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
        <div className="flex items-center mb-4">
          <Brain className="w-6 h-6 text-purple-600 mr-2" />
          <h3 className="text-lg font-semibold text-gray-800">AI Job Suggestions</h3>
        </div>
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="animate-pulse">
              <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-1/2 mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-2/3"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Brain className="w-6 h-6 text-purple-600 mr-2" />
          <h3 className="text-lg font-semibold text-gray-800">AI Job Suggestions</h3>
        </div>
        <div className="flex items-center text-sm text-purple-600 bg-purple-100 px-3 py-1 rounded-full">
          <Zap className="w-4 h-4 mr-1" />
          Powered by AI
        </div>
      </div>

      <div className="space-y-4">
        {suggestions.map((job) => (
          <div key={job.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
            <div className="flex justify-between items-start mb-3">
              <div className="flex-1">
                <h4 className="font-semibold text-gray-800 mb-1">{job.title}</h4>
                <p className="text-sm text-gray-600 mb-2">{job.contractor}</p>
                <div className="flex items-center text-sm text-gray-500 mb-2">
                  <MapPin className="w-4 h-4 mr-1" />
                  <span>{job.location}</span>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center text-lg font-bold text-green-600 mb-2">
                  <IndianRupee className="w-5 h-5" />
                  <span>{job.payPerDay}</span>
                  <span className="text-sm text-gray-500 ml-1">/day</span>
                </div>
                <div className={`px-2 py-1 rounded-full text-xs font-medium ${getMatchColor(job.matchScore)}`}>
                  {job.matchScore}% Match
                </div>
              </div>
            </div>

            <div className="bg-purple-50 p-3 rounded-lg mb-3">
              <div className="flex items-start">
                <Brain className="w-4 h-4 text-purple-600 mr-2 mt-0.5" />
                <p className="text-sm text-purple-800">{job.aiReason}</p>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 text-sm text-gray-500">
                <div className="flex items-center">
                  <Clock className="w-4 h-4 mr-1" />
                  <span>{job.estimatedDuration}</span>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getUrgencyColor(job.urgency)}`}>
                  {job.urgency.toUpperCase()}
                </span>
              </div>
              <button className="bg-purple-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-purple-700 transition-colors">
                Apply Now
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AIJobSuggestions;