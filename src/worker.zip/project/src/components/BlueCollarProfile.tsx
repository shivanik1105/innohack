import React, { useState } from 'react';
import { User, Upload, Check, Star, FileText } from 'lucide-react';
import { useWorker } from '../contexts/WorkerContext';

interface BlueCollarProfileProps {
  onComplete: () => void;
}

const BlueCollarProfile: React.FC<BlueCollarProfileProps> = ({ onComplete }) => {
  const { worker, setWorker } = useWorker();
  const [name, setName] = useState('');
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [certifications, setCertifications] = useState<string[]>([]);
  const [isAvailable, setIsAvailable] = useState(true);

  const skills = [
    { id: 'plumber', label: 'Plumber', icon: '🔧' },
    { id: 'electrician', label: 'Electrician', icon: '⚡' },
    { id: 'painter', label: 'Painter', icon: '🎨' },
    { id: 'carpenter', label: 'Carpenter', icon: '🪚' },
    { id: 'mason', label: 'Mason', icon: '🧱' },
    { id: 'welder', label: 'Welder', icon: '🔥' },
    { id: 'mechanic', label: 'Mechanic', icon: '🔩' },
    { id: 'tiler', label: 'Tiler', icon: '🏠' },
  ];

  const handleSkillToggle = (skill: string) => {
    setSelectedSkills(prev => 
      prev.includes(skill) 
        ? prev.filter(s => s !== skill)
        : [...prev, skill]
    );
  };

  const handleCertificationUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Mock file upload - in real app would upload to server
      setCertifications(prev => [...prev, file.name]);
    }
  };

  const handleSave = () => {
    if (worker && name && selectedSkills.length > 0) {
      setWorker({
        ...worker,
        name,
        skills: selectedSkills,
        certifications,
        isAvailable,
        isVerified: certifications.length > 0
      });
      onComplete();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="max-w-2xl w-full bg-white rounded-2xl shadow-xl p-8">
        <div className="text-center mb-8">
          <div className="bg-indigo-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
            <User className="w-10 h-10 text-indigo-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">
            Professional Profile Setup
          </h2>
          <p className="text-gray-600">
            Build your skilled worker profile with certifications
          </p>
        </div>

        <div className="space-y-8">
          {/* Basic Info */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Full Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="Enter your full name"
            />
          </div>

          {/* Skills Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Select Your Skills
            </label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {skills.map((skill) => (
                <div
                  key={skill.id}
                  onClick={() => handleSkillToggle(skill.id)}
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                    selectedSkills.includes(skill.id)
                      ? 'border-indigo-500 bg-indigo-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="text-2xl mb-2">{skill.icon}</div>
                  <div className="font-medium text-gray-800 text-sm">{skill.label}</div>
                  {selectedSkills.includes(skill.id) && (
                    <Check className="w-4 h-4 text-indigo-500 mt-1" />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Certification Upload */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Upload Certifications (Optional)
            </label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">
                Upload certificates, training badges, or work references
              </p>
              <label className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors cursor-pointer">
                Choose Files
                <input
                  type="file"
                  accept="image/*,.pdf"
                  onChange={handleCertificationUpload}
                  className="hidden"
                  multiple
                />
              </label>
            </div>
            
            {certifications.length > 0 && (
              <div className="mt-4 space-y-2">
                <p className="text-sm font-medium text-gray-700">Uploaded Files:</p>
                {certifications.map((cert, index) => (
                  <div key={index} className="flex items-center bg-green-50 p-3 rounded-lg">
                    <FileText className="w-5 h-5 text-green-600 mr-3" />
                    <span className="text-sm text-gray-800">{cert}</span>
                    <Check className="w-5 h-5 text-green-600 ml-auto" />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Availability */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium text-gray-800">Available for Work</h3>
                <p className="text-sm text-gray-600">Show your availability to employers</p>
              </div>
              <div 
                onClick={() => setIsAvailable(!isAvailable)}
                className={`w-14 h-8 rounded-full cursor-pointer transition-colors relative ${
                  isAvailable ? 'bg-indigo-500' : 'bg-gray-300'
                }`}
              >
                <div 
                  className={`w-6 h-6 bg-white rounded-full absolute top-1 transition-transform ${
                    isAvailable ? 'translate-x-7' : 'translate-x-1'
                  }`}
                />
              </div>
            </div>
          </div>

          {/* Verification Status */}
          {certifications.length > 0 && (
            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <div className="flex items-center">
                <Star className="w-5 h-5 text-green-600 mr-3" />
                <div>
                  <p className="font-medium text-green-800">Verification Eligible</p>
                  <p className="text-sm text-green-600">
                    Your certifications will be verified for a "Verified Worker" badge
                  </p>
                </div>
              </div>
            </div>
          )}

          <button
            onClick={handleSave}
            disabled={!name || selectedSkills.length === 0}
            className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
          >
            Save Profile & Continue
          </button>
        </div>
      </div>
    </div>
  );
};

export default BlueCollarProfile;