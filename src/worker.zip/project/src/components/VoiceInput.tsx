import React, { useState } from 'react';
import { Mic, MicOff, Volume2 } from 'lucide-react';
import { useSpeechSynthesis, useSpeechRecognition } from 'react-speech-kit';

interface VoiceInputProps {
  onResult: (text: string) => void;
  placeholder?: string;
  className?: string;
}

const VoiceInput: React.FC<VoiceInputProps> = ({ onResult, placeholder = "Tap to speak", className = "" }) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');

  const { speak } = useSpeechSynthesis();
  const { listen, listening, stop } = useSpeechRecognition({
    onResult: (result: string) => {
      setTranscript(result);
      onResult(result);
      setIsListening(false);
    },
  });

  const handleVoiceInput = () => {
    if (listening) {
      stop();
      setIsListening(false);
    } else {
      setIsListening(true);
      listen();
      // Provide audio feedback
      speak({ text: "Listening... Please speak now" });
    }
  };

  const speakInstructions = () => {
    speak({ text: placeholder });
  };

  return (
    <div className={`relative ${className}`}>
      <div className="flex items-center space-x-2">
        <button
          onClick={handleVoiceInput}
          className={`flex items-center justify-center p-4 rounded-full transition-all duration-300 ${
            isListening || listening
              ? 'bg-red-500 text-white animate-pulse shadow-lg'
              : 'bg-blue-600 text-white hover:bg-blue-700 shadow-md'
          }`}
        >
          {isListening || listening ? (
            <MicOff className="w-6 h-6" />
          ) : (
            <Mic className="w-6 h-6" />
          )}
        </button>
        
        <button
          onClick={speakInstructions}
          className="p-2 bg-gray-100 text-gray-600 rounded-full hover:bg-gray-200 transition-colors"
          title="Hear instructions"
        >
          <Volume2 className="w-5 h-5" />
        </button>
      </div>
      
      <div className="mt-2">
        <p className="text-sm text-gray-600">{placeholder}</p>
        {(isListening || listening) && (
          <p className="text-sm text-red-500 animate-pulse">🎤 Listening... Speak now</p>
        )}
        {transcript && (
          <p className="text-sm text-green-600 mt-1">✓ Heard: "{transcript}"</p>
        )}
      </div>
    </div>
  );
};

export default VoiceInput;