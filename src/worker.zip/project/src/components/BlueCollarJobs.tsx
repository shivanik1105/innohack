import React, { useEffect, useState } from 'react';
import { MapPin, Phone, Clock, IndianRupee, ArrowLeft, Star, Award } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useWorker } from '../contexts/WorkerContext';

const BlueCollarJobs: React.FC = () => {
  const { worker, jobs, setJobs } = useWorker();
  const navigate = useNavigate();
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    // Mock job data for skilled workers
    const mockJobs = [
      {
        id: '1',
        title: 'Residential Plumbing Work',
        contractor: 'Home Services Pro',
        location: 'DLF Phase 3, Gurgaon',
        payPerDay: 1500,
        description: 'Bathroom renovation, pipe fitting, leak repairs',
        contactNumber: '+91 9876543210',
        postedDate: '2024-01-15',
        urgency: 'high' as const
      },
      {
        id: '2',
        title: 'Commercial Electrical Work',
        contractor: 'Tech Solutions Ltd',
        location: 'Cyber City, Gurgaon',
        payPerDay: 2000,
        description: 'Office wiring, switch installation, testing',
        contactNumber: '+91 9876543211',
        postedDate: '2024-01-15',
        urgency: 'medium' as const
      },
      {
        id: '3',
        title: 'House Painting Project',
        contractor: 'Color Craft',
        location: 'Sector 21, Gurgaon',
        payPerDay: 1200,
        description: 'Interior painting, 3 rooms, premium quality',
        contactNumber: '+91 9876543212',
        postedDate: '2024-01-14',
        urgency: 'low' as const
      },
      {
        id: '4',
        title: 'Furniture Assembly',
        contractor: 'Woodwork Masters',
        location: 'Golf Course Road, Gurgaon',
        payPerDay: 1800,
        description: 'Custom furniture installation, cabinet fitting',
        contactNumber: '+91 9876543213',
        postedDate: '2024-01-15',
        urgency: 'high' as const
      }
    ];
    setJobs(mockJobs);
  }, [setJobs]);

  const filteredJobs = jobs.filter(job => {
    if (filter === 'all') return true;
    return job.urgency === filter;
  });

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleCall = (phoneNumber: string) => {
    window.open(`tel:${phoneNumber}`, '_self');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={() => navigate('/')}
                className="mr-4 p-2 hover:bg-gray-100 rounded-lg"
              >
                <ArrowLeft className="w-6 h-6" />
              </button>
              <div>
                <div className="flex items-center">
                  <h1 className="text-xl font-bold text-gray-800 mr-2">
                    {worker?.name}
                  </h1>
                  {worker?.isVerified && (
                    <div className="flex items-center bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">
                      <Award className="w-3 h-3 mr-1" />
                      <span>Verified</span>
                    </div>
                  )}
                </div>
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <span>{worker?.isAvailable ? '✅ Available' : '❌ Not Available'}</span>
                  <span className="flex items-center">
                    <Star className="w-4 h-4 mr-1 text-yellow-400" />
                    {worker?.rating || 0} ({worker?.jobsCompleted || 0} jobs)
                  </span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">Skills</p>
              <p className="text-sm font-medium">{worker?.skills.join(', ')}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="max-w-4xl mx-auto px-4 py-4">
        <div className="flex space-x-2 overflow-x-auto">
          {[
            { key: 'all', label: 'All Jobs', count: jobs.length },
            { key: 'high', label: 'Urgent', count: jobs.filter(j => j.urgency === 'high').length },
            { key: 'medium', label: 'Medium', count: jobs.filter(j => j.urgency === 'medium').length },
            { key: 'low', label: 'Low', count: jobs.filter(j => j.urgency === 'low').length }
          ].map(filterOption => (
            <button
              key={filterOption.key}
              onClick={() => setFilter(filterOption.key)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                filter === filterOption.key
                  ? 'bg-indigo-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              {filterOption.label} ({filterOption.count})
            </button>
          ))}
        </div>
      </div>

      {/* Jobs List */}
      <div className="max-w-4xl mx-auto px-4 pb-8">
        <div className="space-y-4">
          {filteredJobs.map((job) => (
            <div key={job.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-800 mb-1">
                    {job.title}
                  </h3>
                  <p className="text-gray-600 text-sm mb-2 font-medium">{job.contractor}</p>
                  <div className="flex items-center text-sm text-gray-500 mb-3">
                    <MapPin className="w-4 h-4 mr-1" />
                    <span>{job.location}</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center text-xl font-bold text-green-600 mb-2">
                    <IndianRupee className="w-6 h-6" />
                    <span>{job.payPerDay}</span>
                    <span className="text-sm text-gray-500 ml-1">/day</span>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getUrgencyColor(job.urgency)}`}>
                    {job.urgency.toUpperCase()}
                  </span>
                </div>
              </div>

              <p className="text-gray-700 mb-4">{job.description}</p>

              <div className="flex items-center justify-between">
                <div className="flex items-center text-sm text-gray-500">
                  <Clock className="w-4 h-4 mr-1" />
                  <span>Posted today</span>
                </div>
                <div className="flex space-x-3">
                  <button className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors">
                    Save Job
                  </button>
                  <button
                    onClick={() => handleCall(job.contactNumber)}
                    className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors flex items-center"
                  >
                    <Phone className="w-4 h-4 mr-2" />
                    Contact
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredJobs.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-400 text-6xl mb-4">📭</div>
            <h3 className="text-lg font-medium text-gray-800 mb-2">
              No jobs found
            </h3>
            <p className="text-gray-600">
              Try adjusting your filters or check back later
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default BlueCollarJobs;