import React, { useState } from 'react';
import { Phone, MessageSquare, ArrowRight } from 'lucide-react';
import { useWorker } from '../contexts/WorkerContext';

interface DailyWageLoginProps {
  onLogin: () => void;
}

const DailyWageLogin: React.FC<DailyWageLoginProps> = ({ onLogin }) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [showOTP, setShowOTP] = useState(false);
  const { setWorker, setIsAuthenticated } = useWorker();

  const handleSendOTP = () => {
    if (phoneNumber.length === 10) {
      setShowOTP(true);
    }
  };

  const handleVerifyOTP = () => {
    if (otp === '1234') { // Mock OTP verification
      setIsAuthenticated(true);
      setWorker({
        id: '1',
        name: '',
        phone: phoneNumber,
        workType: [],
        skills: [],
        isAvailable: true,
        rating: 0,
        jobsCompleted: 0,
        certifications: [],
        isVerified: false,
        workerFlow: 'daily-wage'
      });
      onLogin();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8">
        <div className="text-center mb-8">
          <div className="bg-blue-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
            <Phone className="w-10 h-10 text-blue-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">
            Daily Wage Worker Login
          </h2>
          <p className="text-gray-600">
            Enter your phone number to get started
          </p>
        </div>

        {!showOTP ? (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Phone Number
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                  <span className="text-gray-500">+91</span>
                </div>
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
                  placeholder="Enter 10-digit number"
                  maxLength={10}
                />
              </div>
            </div>

            <button
              onClick={handleSendOTP}
              disabled={phoneNumber.length !== 10}
              className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
            >
              Send OTP
              <ArrowRight className="w-5 h-5 ml-2" />
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="text-center">
              <MessageSquare className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <p className="text-gray-600 mb-2">
                OTP sent to +91 {phoneNumber}
              </p>
              <p className="text-sm text-gray-500">
                Demo OTP: 1234
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Enter OTP
              </label>
              <input
                type="text"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg text-center"
                placeholder="Enter 4-digit OTP"
                maxLength={4}
              />
            </div>

            <div className="flex space-x-4">
              <button
                onClick={() => setShowOTP(false)}
                className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-300 transition-colors"
              >
                Back
              </button>
              <button
                onClick={handleVerifyOTP}
                disabled={otp.length !== 4}
                className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
              >
                Verify
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DailyWageLogin;