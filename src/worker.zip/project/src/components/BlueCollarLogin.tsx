import React, { useState } from 'react';
import { Phone, MessageSquare, ArrowRight, Camera } from 'lucide-react';
import { useWorker } from '../contexts/WorkerContext';

interface BlueCollarLoginProps {
  onLogin: () => void;
}

const BlueCollarLogin: React.FC<BlueCollarLoginProps> = ({ onLogin }) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [showOTP, setShowOTP] = useState(false);
  const [photo, setPhoto] = useState<string | null>(null);
  const { setWorker, setIsAuthenticated } = useWorker();

  const handleSendOTP = () => {
    if (phoneNumber.length === 10) {
      setShowOTP(true);
    }
  };

  const handleVerifyOTP = () => {
    if (otp === '1234') { // Mock OTP verification
      setIsAuthenticated(true);
      setWorker({
        id: '1',
        name: '',
        phone: phoneNumber,
        photo: photo || undefined,
        workType: [],
        skills: [],
        isAvailable: true,
        rating: 0,
        jobsCompleted: 0,
        certifications: [],
        isVerified: false,
        workerFlow: 'blue-collar'
      });
      onLogin();
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setPhoto(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8">
        <div className="text-center mb-8">
          <div className="bg-indigo-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
            <Phone className="w-10 h-10 text-indigo-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">
            Skilled Worker Login
          </h2>
          <p className="text-gray-600">
            Professional registration with photo verification
          </p>
        </div>

        {!showOTP ? (
          <div className="space-y-6">
            {/* Photo Upload */}
            <div className="text-center">
              <div className="relative inline-block">
                {photo ? (
                  <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-indigo-200">
                    <img src={photo} alt="Profile" className="w-full h-full object-cover" />
                  </div>
                ) : (
                  <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center border-4 border-indigo-200">
                    <Camera className="w-8 h-8 text-gray-400" />
                  </div>
                )}
                <label htmlFor="photo-upload" className="absolute bottom-0 right-0 bg-indigo-600 text-white p-2 rounded-full cursor-pointer hover:bg-indigo-700 transition-colors">
                  <Camera className="w-4 h-4" />
                  <input
                    id="photo-upload"
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />
                </label>
              </div>
              <p className="text-sm text-gray-500 mt-2">
                Upload your photo for verification
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Phone Number
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                  <span className="text-gray-500">+91</span>
                </div>
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-lg"
                  placeholder="Enter 10-digit number"
                  maxLength={10}
                />
              </div>
            </div>

            <button
              onClick={handleSendOTP}
              disabled={phoneNumber.length !== 10}
              className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
            >
              Send OTP
              <ArrowRight className="w-5 h-5 ml-2" />
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="text-center">
              <MessageSquare className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <p className="text-gray-600 mb-2">
                OTP sent to +91 {phoneNumber}
              </p>
              <p className="text-sm text-gray-500">
                Demo OTP: 1234
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Enter OTP
              </label>
              <input
                type="text"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-lg text-center"
                placeholder="Enter 4-digit OTP"
                maxLength={4}
              />
            </div>

            <div className="flex space-x-4">
              <button
                onClick={() => setShowOTP(false)}
                className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-300 transition-colors"
              >
                Back
              </button>
              <button
                onClick={handleVerifyOTP}
                disabled={otp.length !== 4}
                className="flex-1 bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
              >
                Verify
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BlueCollarLogin;