import React, { useEffect, useState } from 'react';
import { MapPin, Phone, Clock, IndianRupee, ArrowLeft, Briefcase, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useWorker } from '../contexts/WorkerContext';

const DailyWageJobs: React.FC = () => {
  const { worker, jobs, setJobs } = useWorker();
  const navigate = useNavigate();
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    // Mock job data
    const mockJobs = [
      {
        id: '1',
        title: 'Construction Helper Needed',
        contractor: 'ABC Construction',
        location: 'Sector 15, Gurgaon',
        payPerDay: 600,
        description: 'Need 2 helpers for construction work',
        contactNumber: '+91 9876543210',
        postedDate: '2024-01-15',
        urgency: 'high' as const
      },
      {
        id: '2',
        title: 'Loading & Unloading',
        contractor: 'XYZ Logistics',
        location: 'Industrial Area, Gurgaon',
        payPerDay: 550,
        description: 'Loading trucks, physical work required',
        contactNumber: '+91 9876543211',
        postedDate: '2024-01-15',
        urgency: 'medium' as const
      },
      {
        id: '3',
        title: 'Office Cleaning',
        contractor: 'Clean Corp',
        location: 'Cyber City, Gurgaon',
        payPerDay: 450,
        description: 'Daily office cleaning, morning shift',
        contactNumber: '+91 9876543212',
        postedDate: '2024-01-14',
        urgency: 'low' as const
      },
      {
        id: '4',
        title: 'General Labor Work',
        contractor: 'Build Fast',
        location: 'DLF Phase 2, Gurgaon',
        payPerDay: 700,
        description: 'General construction labor work',
        contactNumber: '+91 9876543213',
        postedDate: '2024-01-15',
        urgency: 'high' as const
      }
    ];
    setJobs(mockJobs);
  }, [setJobs]);

  const filteredJobs = jobs.filter(job => {
    if (filter === 'all') return true;
    return job.urgency === filter;
  });

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleCall = (phoneNumber: string) => {
    window.open(`tel:${phoneNumber}`, '_self');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button 
                onClick={() => navigate('/')}
                className="mr-4 p-2 hover:bg-gray-100 rounded-lg"
              >
                <ArrowLeft className="w-6 h-6" />
              </button>
              <div>
                <h1 className="text-xl font-bold text-gray-800">
                  Hi {worker?.name}! 👋
                </h1>
                <p className="text-sm text-gray-600">
                  {worker?.isAvailable ? '✅ Available Today' : '❌ Not Available'}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <div className="text-right">
                <p className="text-sm text-gray-600">Near</p>
                <p className="text-sm font-medium">{worker?.pinCode}</p>
              </div>
              <MapPin className="w-5 h-5 text-gray-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="max-w-4xl mx-auto px-4 py-4">
        <div className="flex space-x-2 overflow-x-auto">
          {[
            { key: 'all', label: 'All Jobs', count: jobs.length },
            { key: 'high', label: 'Urgent', count: jobs.filter(j => j.urgency === 'high').length },
            { key: 'medium', label: 'Medium', count: jobs.filter(j => j.urgency === 'medium').length },
            { key: 'low', label: 'Low', count: jobs.filter(j => j.urgency === 'low').length }
          ].map(filterOption => (
            <button
              key={filterOption.key}
              onClick={() => setFilter(filterOption.key)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                filter === filterOption.key
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              {filterOption.label} ({filterOption.count})
            </button>
          ))}
        </div>
      </div>

      {/* Jobs List */}
      <div className="max-w-4xl mx-auto px-4 pb-8">
        <div className="space-y-4">
          {filteredJobs.map((job) => (
            <div key={job.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-800 mb-1">
                    {job.title}
                  </h3>
                  <p className="text-gray-600 text-sm mb-2">{job.contractor}</p>
                  <div className="flex items-center text-sm text-gray-500 mb-3">
                    <MapPin className="w-4 h-4 mr-1" />
                    <span>{job.location}</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center text-lg font-bold text-green-600 mb-2">
                    <IndianRupee className="w-5 h-5" />
                    <span>{job.payPerDay}</span>
                    <span className="text-sm text-gray-500 ml-1">/day</span>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getUrgencyColor(job.urgency)}`}>
                    {job.urgency.toUpperCase()}
                  </span>
                </div>
              </div>

              <p className="text-gray-700 mb-4">{job.description}</p>

              <div className="flex items-center justify-between">
                <div className="flex items-center text-sm text-gray-500">
                  <Clock className="w-4 h-4 mr-1" />
                  <span>Posted today</span>
                </div>
                <button
                  onClick={() => handleCall(job.contactNumber)}
                  className="bg-green-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-green-700 transition-colors flex items-center"
                >
                  <Phone className="w-4 h-4 mr-2" />
                  Call Now
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredJobs.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-400 text-6xl mb-4">📭</div>
            <h3 className="text-lg font-medium text-gray-800 mb-2">
              No jobs found
            </h3>
            <p className="text-gray-600">
              Try adjusting your filters or check back later
            </p>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4">
        <div className="max-w-4xl mx-auto flex justify-around">
          <button className="text-center">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-1">
              <Briefcase className="w-4 h-4 text-white" />
            </div>
            <span className="text-xs text-blue-600 font-medium">Jobs</span>
          </button>
          <button 
            onClick={() => navigate('/payments')}
            className="text-center"
          >
            <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-1">
              <IndianRupee className="w-4 h-4 text-gray-600" />
            </div>
            <span className="text-xs text-gray-600">Payments</span>
          </button>
          <button 
            onClick={() => navigate('/dashboard')}
            className="text-center"
          >
            <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-1">
              <User className="w-4 h-4 text-gray-600" />
            </div>
            <span className="text-xs text-gray-600">Profile</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default DailyWageJobs;