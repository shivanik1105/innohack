import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { WorkerProvider } from './contexts/WorkerContext';
import LandingPage from './pages/LandingPage';
import DailyWageFlow from './pages/DailyWageFlow';
import BlueCollarFlow from './pages/BlueCollarFlow';
import JobListings from './pages/JobListings';
import WorkerDashboard from './pages/WorkerDashboard';
import PaymentLog from './pages/PaymentLog';
import ChatBot from './components/ChatBot';

function App() {
  return (
    <WorkerProvider>
      <Router>
        <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/daily-wage/*" element={<DailyWageFlow />} />
            <Route path="/blue-collar/*" element={<BlueCollarFlow />} />
            <Route path="/jobs" element={<JobListings />} />
            <Route path="/dashboard" element={<WorkerDashboard />} />
            <Route path="/payments" element={<PaymentLog />} />
          </Routes>
        </div>
        <ChatBot />
      </Router>
    </WorkerProvider>
  );
}

export default App;