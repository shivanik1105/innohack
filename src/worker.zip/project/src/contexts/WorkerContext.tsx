import React, { createContext, useContext, useState, ReactNode } from 'react';

interface Worker {
  id: string;
  name: string;
  phone: string;
  age?: number;
  pinCode?: string;
  region?: string;
  photo?: string;
  workType: string[];
  skills: string[];
  isAvailable: boolean;
  rating: number;
  jobsCompleted: number;
  certifications: string[];
  isVerified: boolean;
  workerFlow: 'daily-wage' | 'blue-collar';
  skillNFTs?: number;
  skillGrowthData?: { month: string; skills: number }[];
  recentActivity?: { type: string; description: string; time: string }[];
  jobStatusData?: { completed: number; pending: number; inProgress: number };
}

interface Job {
  id: string;
  title: string;
  contractor: string;
  location: string;
  payPerDay: number;
  description: string;
  contactNumber: string;
  postedDate: string;
  urgency: 'low' | 'medium' | 'high';
}

interface WorkerContextType {
  worker: Worker | null;
  setWorker: (worker: Worker | null) => void;
  jobs: Job[];
  setJobs: (jobs: Job[]) => void;
  isAuthenticated: boolean;
  setIsAuthenticated: (auth: boolean) => void;
}

const WorkerContext = createContext<WorkerContextType | undefined>(undefined);

export const WorkerProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [worker, setWorker] = useState<Worker | null>(null);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  return (
    <WorkerContext.Provider value={{
      worker,
      setWorker,
      jobs,
      setJobs,
      isAuthenticated,
      setIsAuthenticated
    }}>
      {children}
    </WorkerContext.Provider>
  );
};

export const useWorker = () => {
  const context = useContext(WorkerContext);
  if (context === undefined) {
    throw new Error('useWorker must be used within a WorkerProvider');
  }
  return context;
};